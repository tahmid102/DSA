#include "stack.h"
#include <iostream>
using namespace std;

int initial_capacity=10;
// Constructor implementation
ArrayStack::ArrayStack(int initial_capacity) {
    // TODO: Initialize data members (data, capacity, current_size)
    capacity=initial_capacity;
    data= new int[capacity];
    current_size=0;
    // TODO: Allocate memory for the array with the specified initial capacity
}

// Destructor implementation
ArrayStack::~ArrayStack() {
    // TODO: Free the dynamically allocated memory for the array
    delete [] data;
}

// Push implementation
void ArrayStack::push(int item) {
    // TODO: Check if the array is 50% full (current_size >= capacity/2)
    // TODO: If 50% full, resize the array to double its current capacity
    if(current_size>=capacity/2){
        capacity=capacity*2;
        int *newdata= new int[capacity];
        for(int i=0;i<current_size;i++){
            newdata[i]=data[i];
        }

        delete[] data;
        data= newdata;
        
    }
    
    
    // TODO: Add the new element to the top of the stack and increment current_size
    data[current_size]=item;
    current_size++;
}

// Pop implementation
int ArrayStack::pop() {
    // TODO: Check if the stack is empty, display error message if it is
    if(current_size==0){
        cout<<"error"<<endl;
        return -1;
    }
    // TODO: Decrement current_size and return the element at the top of the stack
    int last=data[current_size-1];

    current_size--;
    // TODO: If the array is less than 25% full, resize it to half its current capacity
    if(current_size*4<capacity){
        capacity=capacity/2;
        int *newdata= new int[capacity];
        for(int i=0;i<current_size;i++){
            newdata[i]=data[i];
        }
        delete [] data;
        data= newdata;
        
    }
   
    
    
    // TODO: Return the popped element
    return last;
}

// Clear implementation
void ArrayStack::clear() {
    // TODO: Reset the stack to be empty (set current_size to 0)
    current_size=0;
    // TODO: No need to free memory, just logically clear the stack

}

// Size implementation
int ArrayStack::size() const {
    // TODO: Return the number of elements currently in the stack (current_size)
    
    return current_size;
}

// Top implementation
int ArrayStack::top() const {
    // TODO: Check if the stack is empty, display error message if it is
    if(current_size==0){
        cout<<"ERROR"<<endl;
        return -1;
    }
    return data[current_size-1];
    // TODO: Return the element at the top of the stack without removing it
}

// Empty implementation
bool ArrayStack::empty() const {
    if(current_size==0)return true;
    else return false;
    // TODO: Return whether the stack is empty (current_size == 0)
}

// Print implementation
void ArrayStack::print() const {
    cout<<"|"<<" ";
    for(int i=current_size-1;i>=0;i--){
        cout<<data[i]<<" ";
    }
    // TODO: Print stack elements from top to bottom in the format: |elem1, elem2, ..., elemN>
}

// Resize implementation
void ArrayStack::resize(int new_capacity) {
    // TODO: Create a new array with the new capacity
    int* newdata= new int[new_capacity];
    for(int i=0;i<capacity;i++){
        newdata[i]=data[i];
    }

    // TODO: Copy elements from the old array to the new array
    // TODO: Delete the old array
    delete[] data;
    data=newdata;
    // TODO: Update the data pointer and capacity
}