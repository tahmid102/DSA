ASSIGNMENT ON STACK
=====================


This assignment was on stack ADT implementation usinng array and linked list data structure
All the functionalities for stack ie: push, pop, empty, print etc were implemented throghout the whole assignment using both the data structures
The tester was introduced to match the expectation with outcomes....

The full code was written in C++. So a C++17-capable compiler (g++, clang++, MSVC) was required to run the files.

Total 18 tests were done and the successrate was 100% which makes the code reliable
Edge cases were handled for more safety


**TO RUN THE TESTER**
======================

Copy  "g++ -std=c++17 test.cpp arraystack.cpp liststack.cpp -o test" in the terminal to COMPILE 
After building simply run .\test.exe

There should be output like 
===== STACK IMPLEMENTATION TESTS =====

----- ArrayStack Tests -----
  ArrayStack - Push Operation: PASSED
  ArrayStack - Pop Operation: PASSED
  ....... .
  ......
  .......




FILES USED 
==============
stack.h
arraystack.cpp
liststack.cpp
test.cpp





AUTHOR
=======

MD. TAHMIDUL ISLAM



