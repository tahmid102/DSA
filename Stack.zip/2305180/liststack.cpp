#include "stack.h"
#include <iostream>
using namespace std;

// Constructor implementation
ListStack::ListStack() {
    // TODO: Initialize head to nullptr
    
    head=NULL;
    // TODO: Initialize current_size to 0
    current_size=0;
}

// Destructor implementation
ListStack::~ListStack() {
    // TODO: Deallocate all nodes in the linked list
    clear();
    // TODO: Consider using the clear() method
}

// Push implementation
void ListStack::push(int item) {
    // TODO: Create a new node with the given item
    // TODO: Make the new node point to the current head
    // TODO: Update head to point to the new node
    // TODO: Increment current_size
    Node* temp= new Node(item,NULL);
    
    if(head==NULL){
        head=temp;
        current_size++;
        return;
    }
    temp->next=head;
    head=temp;
    current_size++;
}

// Pop implementation
int ListStack::pop() {
    // TODO: Check if the stack is empty, display error message if it is
    if(head==NULL || current_size==0){
        cout<<"Error Pop"<<endl;
        return -1;
    }
    // TODO: Store the data from the head node
    int data=head->data;
    Node* old=head;
    // TODO: Update head to point to the next node
    head=head->next;
    // TODO: Delete the old head node
    delete old;
    // TODO: Decrement current_size
    current_size--;
    // TODO: Return the stored data
    return data;
}

// Clear implementation
void ListStack::clear() {
    // TODO: Traverse the linked list, deleting each node
    while(head){
        Node* curr= head;
        head= head->next;
        delete curr;
    }
    // TODO: Reset head to nullptr
    head=NULL;
    current_size=0;
    // TODO: Reset current_size to 0
}

// Size implementation
int ListStack::size() const {
    // TODO: Return the current size (current_size)
    return current_size;
}

// Top implementation
int ListStack::top() const {
    // TODO: Check if the stack is empty, display error message if it is
    if(current_size==0 || head ==NULL){
        cout<<"Error: No element"<<endl;
        return -1;
    }
    // TODO: Return the data from the head node without removing it
    return head->data;
}

// Empty implementation
bool ListStack::empty() const {
    if(current_size==0 && head==NULL){
        return true;
    }
    // TODO: Return whether head is nullptr
    else return false;
}

// Print implementation
void ListStack::print() const {
    // TODO: Print stack elements from top to bottom in the format: |elem1, elem2, ..., elemN>
    Node* curr= head;
    while(curr){
        cout<<curr->data<<" ";
        curr=curr->next;
    }
    // TODO: Traverse the linked list from head, printing each node's data
}